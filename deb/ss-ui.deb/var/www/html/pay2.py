# from . import api

from flask import Flask, request, jsonify, render_template, current_app, jsonify, g, request

from alipay import AliPay
import os


app = Flask(__name__, template_folder='./')
app.config['STATIC_FOLDER'] = 'static'


#下载支付宝的SDK  pip install python-alipay-sdk
#导入alipay 
from alipay import AliPay
@app.route('/pay')
def pay():
    app_id = "9021000122692071"
    # pri_key = "/home/llg/TM/project/cloud/fs/gps-server/key/pri.txt"
    pri_key = "/home/llg/.ssh/id_rsa"
    pub_key = "/home/llg/TM/project/cloud/fs/gps-server/key/pub.txt"
    
    # 创建 AliPay 实例
    alipay = AliPay(
        appid=app_id,
        app_notify_url=None,
        app_private_key_path=pri_key,
        alipay_public_key_path=pub_key,
        sign_type='RSA2',
        debug=True
    )

    # alipay = AliPay(
    #     appid=app_id,
    #     app_notify_url="http://127.0.0.1:5000/paycb",
    #     sign_type='RSA2',
    #     debug=True
    # )

    # 从请求中获取支付参数
    out_trade_no = request.form.get('out_trade_no')
    total_amount = request.form.get('total_amount')
    subject = request.form.get('subject')

    # 构建支付参数
    order_string = alipay.api_alipay_trade_page_pay(
        out_trade_no=out_trade_no,
        total_amount=total_amount,
        subject=subject,
        return_url='http://example.com/return',
        notify_url='http://example.com/notify'
    )

    # 生成支付宝支付页面 URL
    pay_url = alipay.gateway + '?' + order_string

    # 返回支付页面 URL
    return pay_url

@app.route("/<int:order_id>/payment")
# @login_required
def order_pay(order_id):
    print("id", order_id)
    return "aa"
if __name__ == '__main__':
    pay()    
    app.run(host="0.0.0.0")

