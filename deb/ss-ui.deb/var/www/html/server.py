#!/usr/bin/python3

import os
from flask import Flask, request, jsonify, render_template
import json
import logging
from logging.handlers import RotatingFileHandler
# from __future__ import print_function
import sys
#from flask_caching import Cache

app = Flask(__name__, template_folder='./')
#cache = Cache(app, config={'CACHE_TYPE': 'null'})
app.config['STATIC_FOLDER'] = 'static'
# app = Flask(__name__, template_folder='/home/dev-wml/TM/project/cloud/fs/gps-server/')
# app = Flask(__name__)


def insert_file(fname, data):
    with open(fname, 'a+') as file:
        file.write(f'{data.get("ip")}  {data.get("alias")}\n')


def insert_file_gps(fname, data):
    with open(fname, 'a+') as file:
        file.write(f'{data.get("date")}, {data.get("latitude")}, {data.get("longitude")}, {data.get("altitude")}\n')
        # file.write(f'{data.get("date")}, {data.get("latitude")}, {data.get("longitude")}, {11}\n')

def insert_acl(fname, ip):
    with open(fname, 'a+') as file:
        file.write(f'{ip}\n')

# ajax版本
@app.route('/api/data', methods=['POST'])
def process_ajax_request():
    # 从 AJAX 请求中获取数据
    data = request.json

    # 处理数据
    ip = data.get('ip')
    alias = data.get('alias')

    # 执行其他操作，例如保存到数据库等
    insert_file("/tmp/acl.txt", data);
    # 构建响应数据
    response_data = {
        'status': 'success',
        'message': f'Hello, {ip}! Your age is {alias}.'
    }

    print(response_data)
    # 返回 JSON 格式的响应
    return jsonify(response_data)
    # return jsonify;


'''
curl -X POST -H "Content-Type: application/json"  \
    -d '{"latitude":37.7749,"longitude":-122.4194}'  \
        http://127.0.0.1:5000/api/gps
'''

# ajax版本
@app.route('/api/gps', methods=['POST'])
def save_gps():
    # 从 AJAX 请求中获取数据
    data = request.json
    logging.debug("sdf\r\n");
    # 处理数据
    latitude = data.get('latitude')
    longitude = data.get('longitude')
    altitude = data.get('altitude')

    print("latitude " ,latitude, "longitude", longitude)
    insert_file_gps("/tmp/gps.txt", data)
    # response_data = {
    #     'status': 'success',
    #     'message': f'Hello'
    # }
    response = jsonify({'success': True})
    # response.headers.add('Access-Control-Allow-Origin', '*')
    # response.headers.add('Access-Control-Allow-Origin', 'http://127.0.0.1:5000')
    # response.headers.add('Access-Control-Allow-Headers' "Content-Type, Authorization")
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
    response.headers.add('Access-Control-Allow-Credentials', 'true')
    return response

@app.route('/')
def page_index():
    return render_template("index.html", username="jON")

@app.route('/gps')
def page_gps():
    return render_template("auto.html")

@app.route('/buy/x360')
def page_buy():
    return render_template("auto.html")

@app.route('/acl')
def page_acl():

    # data = request.json
    # logging.debug("sdf\r\n");
    # 处理数据
    # latitude = data.get('latitude')

    # ip = request.remote_addr
    # print('Hello world!', ip)
    # insert_acl('/tmp/acl', ip)
    return render_template("acl.html")

@app.route('/acl/add', methods=['POST'])
def page_acl_add():
    data = request.json
    # 处理数据
    print(data)
    ip = data.get('ip')
    insert_acl('/tmp/acl', ip)
    print("ip ", ip)
    response = jsonify({'status': 'success'})
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
    response.headers.add('Access-Control-Allow-Credentials', 'true')
    return response

@app.route('/acl/update', methods=['POST'])
def page_acl_update():
    print("sssssss")
    os.system("ss-iptables.sh")
    response = jsonify({'status': 'success'})
    return response;
if __name__ == '__main__':
    log_file = os.path.join(app.root_path, 'logs', 'app.log')
    handler = RotatingFileHandler(log_file, maxBytes=10000, backupCount=1)

    app.logger.setLevel(logging.DEBUG)
    #app.run(host="0.0.0.0", ssl_context=('/etc/nginx/ssl/example.crt', '/etc/nginx/ssl/example.key'))
#    app.run(host="0.0.0.0", ssl_context=('adhoc'))
    
    app.run(host="0.0.0.0")

