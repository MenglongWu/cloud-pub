from flask import Flask
import os
import logging
from logging.handlers import RotatingFileHandler

from gps import gps_r


app = Flask(__name__)

app = Flask(__name__, template_folder='./')
app.config['STATIC_FOLDER'] = 'static'

app.register_blueprint(gps_r)

# if __name__ == '__main__':
#     app.run()
if __name__ == '__main__':
    log_file = os.path.join(app.root_path, 'logs', 'app.log')
    handler = RotatingFileHandler(log_file, maxBytes=10000, backupCount=1)

    app.logger.setLevel(logging.DEBUG)
    #app.run(host="0.0.0.0", ssl_context=('/etc/nginx/ssl/example.crt', '/etc/nginx/ssl/example.key'))
#    app.run(host="0.0.0.0", ssl_context=('adhoc'))
    
    app.run(host="0.0.0.0")

