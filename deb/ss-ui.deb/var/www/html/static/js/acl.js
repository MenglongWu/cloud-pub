


function error(error) { 
    var err = error.code;
    switch (err) {
        case 1: alert("用户拒绝了"); break;
        case 2: alert("获取不到信息"); break;
        case 3: alert("获取信息超时");
    }
}
function isIPv4(str) {
    return /^(\d{1,3}\.){3}\d{1,3}$/.test(str) && str.split('.').every(function(segment) {
      return parseInt(segment, 10) <= 255;
    });
  }
  
function acl_add() {
    // 获取输入的数据
    var ip = document.getElementById("ip").value
    if (false == isIPv4(ip)) {
        console.log("good bay")
        return ;
    }
    console.log("good")
    var urlDataJson =
    {
        'ip': ip
    };

    var htmlobj = $.ajax(
    {
        url : "/acl/add",
        type : "POST",
        contentType : 'application/json',       
        data : JSON.stringify(urlDataJson),
        async : false,
        success     : function(response) {
            console.log('Success:', response);
        }
    });
}


function acl_update() {
    var urlDataJson =
    {
    };

    var htmlobj = $.ajax(
    {
        url : "/acl/update",
        type : "POST",
        contentType : 'application/json',       
        data : JSON.stringify(urlDataJson),
        async : false,
        success     : function(response) {
            console.log('Success:', response);
        }
    });
    console.log("update")
}