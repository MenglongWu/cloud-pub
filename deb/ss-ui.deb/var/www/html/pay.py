#!/usr/bin/python3

from flask import Flask, request
import requests
import json
import rsa

# app = Flask(__name__)
app = Flask(__name__, template_folder='./')
app.config['STATIC_FOLDER'] = 'static'

# @app.route('/pay', methods=['POST'])
@app.route('/pay')
def pay():
    print("this pay")
    # 沙箱环境的支付宝接口地址
    # sandbox_url = "https://openapi.alipaydev.com/gateway.do"
    sandbox_url =  "https://openapi-sandbox.dl.alipaydev.com/gateway.do"

    # 沙箱环境的APPID和私钥
    app_id = "9021000122692071"
    private_key = "MIIEpQIBAAKCAQEAndCex+G3JTi7B4Xt4gDOs+KSoGxL+Izdt18hwPeJKkxd31pjO1bjCFlb95XOwaWHwlQdwf2ymnJwnJzlY5Q87gisTZb8etrrYggh1il/veJfEG5i8pia8YPqiaz9KZh0V3EGnyk0hbY0rNTSODPHHz559eHzxHBW+PB9o/tD12ZZA/CxVcCaLPhLEMcaG+HRi/xKO/ORYVgbUEUOtMhAnURRypJ+xcBJ6Q0L2sBdoZFPiIyal5MiYbtEh029CcDq1FDt9DhXtSz7YenRi6dJ9zCNUGzdl1lhDh1H7SlRx1v4SXzygK7u+KuQvp6/YHuowm+OIZZ5JMEGYUFZ7+lh5QIDAQABAoIBAQCbeW0ENI3PAL3ZYouCLRN2ys9zdl2+B2FjBzjkt7mNT2Dn6095pVbT4d0l5JOl2WMPAvmyJTMwz2+8CyI+YUtJoofFhOtGSai9ko9rQsUTmBHZyTZ4E/oJ19FXQ3LB6O0tPC+u29RfqqroXl6gefpBALb8k1cpfxdf9uWAiMlESX8uqy2PnABSC23oi+ub+ZiUW6S6/Bc7S/DjEqZEx5oMaKbsPba/8KaZCo/4FOo3GTqDmXOnhjsoO20mATxpQKi2sEOeeZgoQ27eGA40Gmm1iTm7wJujF/TKgRy1LN90gph6h3Tvwl/Cpwa/A3Qk09fzS/s4oBj6dnU171FXhYBhAoGBAPaVj8xeqEhdnpjuoVnaSPSwt03gpGtxDWtDSmrH4uO+d68VBD0b7OSO/yaU75xZGFjcaIa9mW6L+wt2sUvOC86IrcZ+0v4REpHjlgOlG9PKrN7ZtEiBFQ1LgKq041YX4DigJqxabyZ3eQox/aD9k83yv66caLwBs/VPgwg9n789AoGBAKPXT4nn7DWSMfyQfG7iDkWhuX8w7pd8lqgDexO9lASAnK+BMgTRYwywD/YY/NczmFUKPwznprBI0hh5kSb+omRUg9lpoYMz4zDpLy+2Yiu/RGATa5ixPYslOcAE+tkRzZ83JTaZC+Us6xIf/t/XZLOSt6+i81gLC5O/APYxYNfJAoGBAMWjOo5jkB3wa53IJisOekslGMaityYmhsriNFNBwuknUGZUQgF40Hag5oDV/vchshIHFwBoFwIz0BNwHsrTa0Mu6ZmfLR3WMTwdXa+uNo+actRrScSTMXxmd8pbEZt/p4e7VUPveAcs2ycAyniuxjjbyCb71jZaZxLHmA6S1edBAoGAX+6A9uliCBf6xrw+75nS63h/KXcYLIDZobSwCuX01hIMLEMEa4fCbDpmjh0hZkwihKCEPGUi15M72PLNR7zOjtphfRp5ZF4sR4Yxh8lNf/n06iBU3snglCmOv9zql9Dxyai7VFWWfnCnjyxGyv/OScq9XMyXmVSWScMLqBtPbekCgYEAwjLftCkkqDZRMXMSxF8uxKgcDZNp/+PtqYFHPP7fpgK0/dPjyGCaQGyBWpaU+m3gPXI1WgAwJQ2efSctHaJLgBnwR3x27mm/Ksnd16AVrSA04B56Ssdhf7iQwI6P/G+c4DORrQN++t/yimt6Ldu3P0urt/ZXhyBYMF6QJcUVetk="

    # 沙箱环境的公钥
    alipay_public_key = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAndCex+G3JTi7B4Xt4gDOs+KSoGxL+Izdt18hwPeJKkxd31pjO1bjCFlb95XOwaWHwlQdwf2ymnJwnJzlY5Q87gisTZb8etrrYggh1il/veJfEG5i8pia8YPqiaz9KZh0V3EGnyk0hbY0rNTSODPHHz559eHzxHBW+PB9o/tD12ZZA/CxVcCaLPhLEMcaG+HRi/xKO/ORYVgbUEUOtMhAnURRypJ+xcBJ6Q0L2sBdoZFPiIyal5MiYbtEh029CcDq1FDt9DhXtSz7YenRi6dJ9zCNUGzdl1lhDh1H7SlRx1v4SXzygK7u+KuQvp6/YHuowm+OIZZ5JMEGYUFZ7+lh5QIDAQAB"

    # 从请求中获取支付参数
    out_trade_no = request.form.get('out_trade_no')
    total_amount = request.form.get('total_amount')
    subject = request.form.get('subject')

    # 构建请求参数
    params = {
        "app_id": app_id,
        "method": "alipay.trade.pay",
        "charset": "utf-8",
        "sign_type": "RSA2",
        "timestamp": "2023-06-18 12:00:00",
        "version": "1.0",
        "biz_content": {
            "out_trade_no": out_trade_no,
            "total_amount": total_amount,
            "subject": subject,
            "product_code": "QUICK_WAP_PAY"
        }
    }

    # 对参数进行签名
    param_string = "&".join([f"{key}={params[key]}" for key in sorted(params.keys())])
    # sign = rsa.sign(param_string.encode("utf-8"), private_key, "SHA-256")
    sign = rsa.PublicKey.load_pkcs1(private_key)
    # 添加签名到请求参数中
    params["sign"] = sign

    # 发送请求
    response = requests.post(sandbox_url, data=params)

    # 解析响应
    response_data = json.loads(response.text)

    # 处理响应结果
    if response_data["alipay_trade_pay_response"]["code"] == "10000":
        # 支付成功，处理自己的业务逻辑
        trade_no = response_data["alipay_trade_pay_response"]["trade_no"]
        return "支付成功，支付宝交易号：" + trade_no
    else:
        # 支付失败，处理自己的业务逻辑
        error_msg = response_data["alipay_trade_pay_response"]["sub_msg"]
        return "支付失败，错误信息：" + error_msg

@app.route('/paycb')
def page_pay():
    print("sss")
    return "sdsf"
    # return render_template("acl.html")


if __name__ == '__main__':
    
    app.run(host="0.0.0.0")

