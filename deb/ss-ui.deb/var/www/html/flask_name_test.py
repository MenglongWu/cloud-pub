#!/usr/bin/python3

import requests
import time
# url = 'http://localhost:5000/save'
# url = 'http://38.47.239.42:5000/save'
url = 'http://38.47.221.54:5000/save'
url = 'http://127.0.0.1:5000/api/gps'

# url = 'http://test05.nicelong.top:84/save'
# url = 'http://localhost:5000/save'
# url = 'http://localhost:81/save'
# url = 'http://localhost:81/api/data'
# url = 'http://localhost/api/data'
# url = 'http://test05.nicelong.top:5000/save'
data = {
    'age': '25',
    'name': 'John'
}

# 长连接
def post_keep():
    session = requests.Session()
    session.keep_alive = True


    for i in range(1, 10):
        data["age"] = i
        response = session.post(url, data=data)
        print(response.status_code)
        print(response.text)
    session.close()

# 短连接版本
def post():
    for i in range(1, 10):
        data["age"] = i
        response = requests.post(url, data=data)

    if response.status_code == 200:
        print('Data saved successfully!')
    else:
        print('Failed to save data.')



def test_ajax_request():

    # 发送 POST 请求
    response = requests.post(url, json=data)
    # time.sleep(1)
    # # 解析响应数据
    response_data = response.json()
    # print(response.status_code, response_data)
    # # 处理响应
    if response.status_code == 200 and response_data.get('status') == 'success':
        message = response_data.get('message')
        print(message)
    else:
        print('Request failed.')

data1 = {
    'latitude': '25',
    'longitude': 'John'
}

def test_ajax_gps():

    # 发送 POST 请求
    response = requests.post(url, json=data1)
    # time.sleep(1)
    # # 解析响应数据
    response_data = response.json()
    # print(response.status_code, response_data)
    # # 处理响应
    if response.status_code == 200 and response_data.get('status') == 'success':
        message = response_data.get('message')
        print(message)
    else:
        print('Request failed.')

if __name__ == '__main__':
    # post_keep()
    # post()
    # test_ajax_request();
    test_ajax_gps();

