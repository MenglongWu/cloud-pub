#!/bin/bash

IP=${1:-"127.0.0.1"}
ISEC=${2:-60}

#kill $(pidof pub.elf)

#sleep 2

function rdata() {
    # NAME=$(hexdump /dev/random -n 12 | md5sum)
    NAME=$(echo ${RANDOM}${RANDOM}${RANDOM}${RANDOM} | md5sum)

    # NAME="sss"
    BATT_VAL=$(cat /proc/uptime  | awk -F '.' '{print $3}')
    let TEMP_VAL=($RANDOM%10)+50
	H=$(hostname | awk '{printf("%10.10s\n",$0)}')
    # D=$(hexdump /dev/random -n 12 | md5sum)    
    D=$(echo ${RANDOM}${RANDOM}${RANDOM}${RANDOM} | md5sum)
    ALARM_VAL="$((RANDOM%10))-$((RANDOM%10))-$((RANDOM%10))-$((RANDOM%10))-$((RANDOM%10))"
	echo -e ${NAME} H:"${H}" batt: "${BATT_VAL}" alarm:"${ALARM_VAL}" tempture:"${TEMP_VAL} $K"
}


while [ 1 ];
do
    kill $(pidof pub.elf)
    DATA=$(rdata)
    /app/pub.elf ${IP} 1883 5 "${DATA}" &
    DATA=$(rdata)
    /app/pub.elf ${IP} 1883 8 "${DATA}" &
    DATA=$(rdata)
    /app/pub.elf ${IP} 1883 8 "${DATA}" &

    let SEC=($RANDOM%80+$ISEC)
    sleep ${SEC}


done
